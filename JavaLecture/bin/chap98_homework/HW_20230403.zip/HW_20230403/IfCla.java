package chap98_homework.HW_20230403;

public class IfCla {
	public void makeIf(int num) {
		if(num == 1) {
			System.out.println("정답입니다.");
		}
	}
}
