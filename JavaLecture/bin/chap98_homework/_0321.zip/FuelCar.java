package chap98_homework._0321;

public interface FuelCar extends Car {
	void addFuel();
}
