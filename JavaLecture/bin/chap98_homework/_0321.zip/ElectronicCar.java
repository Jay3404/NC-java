package chap98_homework._0321;

public interface ElectronicCar extends Car {
	void charge();
}
