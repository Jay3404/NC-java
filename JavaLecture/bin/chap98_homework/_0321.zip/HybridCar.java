package chap98_homework._0321;

public class HybridCar implements ElectronicCar, FuelCar{

	@Override
	public void speedUp() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void speedDown() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addFuel() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void charge() {
		// TODO Auto-generated method stub
		
	}

}
