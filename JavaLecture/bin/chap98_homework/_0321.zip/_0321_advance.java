package chap98_homework._0321;

public class _0321_advance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WorkerProgram wp = new WorkerProgram();
		wp.start();
	}

}
