package practice.studentProgram;

import practice.studentProgram.main.Program;

public class _0323_advance {
    public static void main(String[] args) {
        Program program = new Program();
        program.start();
    }
}
