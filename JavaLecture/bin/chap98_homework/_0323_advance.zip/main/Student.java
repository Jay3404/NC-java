package practice.studentProgram.main;

import practice.studentProgram.pages.Pages;

public interface Student {
//    1. 인터페이스 Student
//    - void saveInfo();
//    - void printInfo();
//    - double getAvg(); => round로 소수점 두 자리까지만 표출

//    void saveInfo();
    void printInfo();
    double getAvg();
}
