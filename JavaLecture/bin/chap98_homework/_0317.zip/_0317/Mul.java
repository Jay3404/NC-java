package chap98_homework._0317;

public class Mul extends Calc{
	public int calculate() {
		result = a * b;
		return result;
	}
}
