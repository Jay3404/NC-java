package chap98_homework._0317;

public class Calc {
	int a, b;
	int result;
	public void setValue(int a, int b) {
		this.a = a;
		this.b = b;
	}
	
	public int calculate() {
		return result;
	}
}
