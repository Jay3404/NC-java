package chap98_homework._0317;

public class _0317_advance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RockScissPaper rsp = new RockScissPaper();
		rsp.start();
	}

}
