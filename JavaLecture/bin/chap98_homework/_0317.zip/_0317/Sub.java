package chap98_homework._0317;

public class Sub extends Calc{
	public int calculate() {
		result = a - b;
		return result;
	}
}
